/**
 * Created by zhaoyadong on 28/07/2014.
 */
const index = require("../controllers/index.js");

module.exports = function (app, wss) {
    app.get("/", index.home);
};
