var http = require("http");
var express = require("express");
var path = require("path");
// 引入 cookie 处理对象
var cookieParser = require("cookie-parser");
var bodyParser = require("body-parser");

var routes = require("./routes");
//var http = require('http');
var domain = require("domain");

var app = express();

app.set("port", process.env.PORT || 4000);

// view engine setup
app.engine("html", require("express-art-template"));
app.set("views", path.join(__dirname, "views"));
app.set("view engine", "html");

// 定义使用 cookie 处理对象
app.use(cookieParser());
app.use("/static", express.static("static"));

app.use(function (err, req, res, next) {
    if (err.name === "UnauthorizedError") {
        res.status(401).send("invalid token");
    }
});
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());

// 处理没有捕获的异常，导致 node 退出
app.use(function (req, res, next) {
    var reqDomain = domain.create();
    reqDomain.on("error", function (err) {
        res.status(err.status || 500);
        res.render("error");
    });
    reqDomain.run(next);
});

/*
app.use(express.static(__dirname, '/public'));
app.use(express.static(__dirname + '/files'));
app.use(express.static(__dirname + 'uploads'));
*/

// 配置允许跨域
app.all("*", function (req, res, next) {
    res.header("Access-Control-Allow-Origin", "*");
    res.header("Access-Control-Allow-Headers", "*");
    res.header("Access-Control-Allow-Methods", "*");
    res.header("X-Powered-By", " 3.2.1");
    res.header("Content-Type", "application/json;charset=utf-8");
    next();
});

routes(app);

var server = require('http').Server(app);
var io = require('socket.io')(server);
io.sockets.on('connection', function(socket) {
    // 监听客户端发送的 chat 事件
    socket.on('chat', function (chatinfo) {
        // 向当前 socket 发送聊天信息
        socket.emit('chat', chatinfo);
        // 向除了当前 socket 外的所有 socket 发送聊天信息
        socket.broadcast.emit('chat', chatinfo);
    });
});

module.exports = server;
